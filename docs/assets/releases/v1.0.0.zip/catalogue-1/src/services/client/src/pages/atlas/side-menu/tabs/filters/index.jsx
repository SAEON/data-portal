import { Typography, Box } from '@material-ui/core'

export default () => {
  return (
    <Box m={1}>
      <Typography variant="overline">Under construction!</Typography>
    </Box>
  )
}
