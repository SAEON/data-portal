import { Grid, Fade } from '@material-ui/core'
import { isMobile } from 'react-device-detect'

// Metadata fields
import Titles from './_titles'
import Creators from './_creators'
import GeoLocations from './_geo-locations'
import Dates from './_dates'
import Publisher from './_publisher'
import Contributors from './_contributors'
import Descriptions from './_descriptions'
import Subjects from './_subjects'
import LinkedResources from './_linked-resources'
import Identifiers from './_identifiers'
import RightsList from './_rights-list'

export default ({
  codeView,
  titles,
  creators,
  geoLocations,
  dates,
  publisher,
  publicationYear,
  contributors,
  descriptions,
  subjects,
  linkedResources,
  identifier,
  alternateIdentifiers,
  rightsList,
}) => {
  return (
    <div style={{ margin: isMobile ? '16px 0 16px' : '32px 0px 32px' }}>
      <Grid container justify="center">
        <Grid item lg={10} xl={8}>
          <Fade key="field-view" in={!codeView}>
            <Grid
              container
              direction="column"
              justify="space-evenly"
              alignItems="stretch"
              spacing={isMobile ? 2 : 3}
            >
              {titles?.length && <Titles titles={titles} />}
              {creators?.length && <Creators creators={creators} />}
              {rightsList?.length && <RightsList rightsList={rightsList} />}
              {geoLocations?.length && <GeoLocations geoLocations={geoLocations} />}
              {dates?.length && <Dates dates={dates} />}
              {publisher && <Publisher publisher={publisher} publicationYear={publicationYear} />}
              {contributors?.length && <Contributors contributors={contributors} />}
              {descriptions?.length && <Descriptions descriptions={descriptions} />}
              {subjects?.length && <Subjects subjects={subjects} />}
              {linkedResources?.length && <LinkedResources linkedResources={linkedResources} />}
              <Identifiers identifier={identifier} alternateIdentifiers={alternateIdentifiers} />
            </Grid>
          </Fade>
        </Grid>
      </Grid>
    </div>
  )
}
