export default dois => ({
  terms: {
    'identifier.identifier.raw': dois,
    boost: 100,
  },
})
