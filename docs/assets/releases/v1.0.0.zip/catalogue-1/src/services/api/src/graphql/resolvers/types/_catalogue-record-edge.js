export default {
  cursor: async self => {
    return self._id
  },
  node: async self => self,
}
