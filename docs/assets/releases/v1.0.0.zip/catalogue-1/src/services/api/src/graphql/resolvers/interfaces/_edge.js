export default {
  // eslint-disable-next-line no-unused-vars
  __resolveType: async edge => {
    // TODO
  },
}
