export default {
  id: async self => self._id,
}
