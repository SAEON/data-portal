// import descriptor from '../../lib/proxy-descriptor'
// import packageJson from '../../../package.json'

// eslint-disable-next-line no-unused-vars
export default ({ map, rerender }) => {
  return 'hi'
}
