var token

export const getToken = () => token

export const setToken = newToken => {
  token = newToken
}
